# 🌍 AI Disaster Alert & Emergency Assistant
AI-based flood risk prediction, earthquake **risk indicator**, alert engine, explainability and a safety chatbot (Streamlit).

> Academic decision-support prototype. It does NOT predict exact time/location/magnitude of earthquakes. Always follow official warnings.

## Run locally
```bash
python -m venv venv && venv\Scripts\activate      # (Linux/Mac: source venv/bin/activate)
pip install -r requirements.txt
streamlit run app.py
```

## Your dataset (`archive__2_.zip` → `seattle-weather.csv`) - what the app does with it
- 1,461 daily rows (2012-2015): `date, precipitation, temp_max, temp_min, wind, weather` - no missing values.
- **Not in the dataset:** flood label, humidity, pressure, water level, soil moisture, latitude/longitude, any earthquake data.
- So the app **derives**: previous-3-day and previous-14-day rainfall (runoff / ground-wetness proxies), temperature range, seasonality, one-hot weather type,
  and a proxy target **`heavy_rain_next_day`** (next-day rain >= 90th percentile ≈ 9.9 mm). Flood risk here = *heavy-rainfall (flood-precursor) risk*, not observed floods.
- Models are evaluated with a **chronological split** (train on first 80% of days, test on last 20%). Real result: ROC-AUC ≈ 0.8.
- Earthquake: no seismic data → no indicator unless you upload a catalogue (e.g. USGS CSV) or enable the clearly-labelled SYNTHETIC demo catalogue.

## Use YOUR dataset
1. Put your `.zip` / `.csv` / `.xlsx` into `data/` (or use the sidebar uploader). ZIPs are read automatically.
2. The app auto-detects columns (rainfall, temperature, humidity, wind, pressure, water level, soil moisture, lat/lon, elevation, magnitude, depth, date).
3. Flood table = any file with a column whose name contains `flood` (0/1, Yes/No, Low/High, or a 0-1 probability). It is converted to a binary label.
4. Earthquake catalogue = any file with magnitude + latitude + longitude columns.
5. Models retrain automatically (cached). Best model is saved to `models/flood_model.pkl`.
If `data/` has no usable file, the app runs in clearly-labelled **DEMO MODE with SYNTHETIC data**.

## Modules
- `src/preprocessing.py` – loading, ZIP handling, schema detection, synthetic demo data
- `src/flood_prediction.py` – trains Logistic Regression / Decision Tree / Random Forest / Gradient Boosting (+XGBoost if installed), picks best by ROC-AUC, permutation importance, local explanation
- `src/earthquake_risk.py` – historical-catalogue risk indicator (density percentile + max magnitude + shallow share)
- `src/alert_engine.py` – NORMAL / WATCH / WARNING / EMERGENCY (earthquake indicator is capped at WARNING)
- `src/assistant.py` – offline safety KB; uses an LLM if `ANTHROPIC_API_KEY` is set (env var or `.streamlit/secrets.toml`)

## Deploy on Streamlit Cloud
Push this folder to GitHub → share.streamlit.io → New app → select repo, main file `app.py` → (optional) add `ANTHROPIC_API_KEY` under Secrets.

## Demo flow (5 min)
1. Dashboard → alert, cards, charts. 2. Flood Prediction → Scenario 1 (heavy rain → HIGH / 🟠 WARNING), then Scenario 2 (🟢 LOW / NORMAL); show "Why this prediction?".
3. Earthquake Risk → tick the SYNTHETIC demo catalogue → Scenario 3 + disclaimer (say clearly it is synthetic). 4. Assistant → ask "What if water enters my house?". 5. Risk Map, Data Analysis (metrics).

## Limitations
No live weather/sensor feed; no real SMS/email; earthquake output is a historical heuristic; accuracy depends on your dataset.
## Future scope
Live weather/river APIs, SHAP, LSTM time-series, real notifications, multilingual assistant.
