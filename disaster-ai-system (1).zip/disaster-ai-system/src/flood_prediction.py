"""Flood risk ML pipeline: train several models, compare, select best, explain."""
import os, warnings
import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, average_precision_score
from sklearn.inspection import permutation_importance
from .preprocessing import detect_flood_target, to_binary_target

warnings.filterwarnings("ignore")
MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")
LEVELS = ["LOW", "MODERATE", "HIGH", "EXTREME"]


DEFAULT_TH = (0.25, 0.5, 0.75)


def risk_level(p, th=DEFAULT_TH):
    return LEVELS[0] if p < th[0] else LEVELS[1] if p < th[1] else LEVELS[2] if p < th[2] else LEVELS[3]


def select_features(df, target, max_features=25):
    num = df.select_dtypes(include=np.number).columns.tolist()
    drop = {target}
    feats = [c for c in num if c not in drop and df[c].nunique() > 1 and "id" != c.lower()]
    return feats[:max_features]


def _candidates():
    models = {
        "Logistic Regression": Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler()),
                                         ("m", LogisticRegression(max_iter=2000, class_weight="balanced"))]),
        "Decision Tree": Pipeline([("imp", SimpleImputer(strategy="median")),
                                   ("m", DecisionTreeClassifier(max_depth=5, min_samples_leaf=10, class_weight="balanced", random_state=42))]),
        "Random Forest": Pipeline([("imp", SimpleImputer(strategy="median")),
                                   ("m", RandomForestClassifier(n_estimators=200, min_samples_leaf=5, class_weight="balanced", n_jobs=-1, random_state=42))]),
        "Gradient Boosting": Pipeline([("imp", SimpleImputer(strategy="median")),
                                       ("m", GradientBoostingClassifier(random_state=42))]),
    }
    try:  # optional
        from xgboost import XGBClassifier
        models["XGBoost"] = Pipeline([("imp", SimpleImputer(strategy="median")),
                                      ("m", XGBClassifier(n_estimators=150, max_depth=4, eval_metric="logloss", verbosity=0))])
    except Exception:
        pass
    return models


def train_flood_model(df, target=None, save=True, time_split=False):
    """Returns dict with best pipeline, metrics table, feature list, importances, stats."""
    target = target or detect_flood_target(df)
    if target is None:
        raise ValueError("No flood target column found (a column whose name contains 'flood').")
    data = df.dropna(subset=[target]).copy()
    if len(data) > 60000:
        data = data.sample(60000, random_state=42)
    y = to_binary_target(data[target])
    if y.nunique() < 2:
        raise ValueError("Flood target has only one class - cannot train a classifier.")
    feats = select_features(data, target)
    if not feats:
        raise ValueError("No numeric feature columns available for training.")
    X = data[feats]
    if time_split:  # chronological split (no peeking into the future)
        n = int(len(X) * 0.8)
        Xtr, Xte, ytr, yte = X.iloc[:n], X.iloc[n:], y.iloc[:n], y.iloc[n:]
    else:
        Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
    rows, fitted = [], {}
    for name, pipe in _candidates().items():
        try:
            pipe.fit(Xtr, ytr)
            pr = pipe.predict(Xte)
            proba = pipe.predict_proba(Xte)[:, 1]
            rows.append({"Model": name, "Accuracy": accuracy_score(yte, pr),
                         "Precision": precision_score(yte, pr, zero_division=0),
                         "Recall": recall_score(yte, pr, zero_division=0),
                         "F1 Score": f1_score(yte, pr, zero_division=0),
                         "ROC-AUC": roc_auc_score(yte, proba),
                         "PR-AUC": average_precision_score(yte, proba)})
            fitted[name] = pipe
        except Exception as e:
            rows.append({"Model": name + " (failed)", "Accuracy": np.nan, "Precision": np.nan,
                         "Recall": np.nan, "F1 Score": np.nan, "ROC-AUC": np.nan, "PR-AUC": np.nan})
    metrics = pd.DataFrame(rows).dropna().sort_values("ROC-AUC", ascending=False).reset_index(drop=True)
    best_name = metrics.iloc[0]["Model"]
    best = fitted[best_name]
    sample = Xte.sample(min(len(Xte), 500), random_state=1)
    pi = permutation_importance(best, sample, yte.loc[sample.index], n_repeats=5, random_state=0, scoring="roc_auc")
    imp = pd.Series(np.clip(pi.importances_mean, 0, None), index=feats).sort_values(ascending=False)
    imp = imp / imp.sum() if imp.sum() > 0 else imp
    cm = confusion_matrix(yte, best.predict(Xte))
    stats = {"median": X.median().to_dict(), "q05": X.quantile(0.05).to_dict(), "q95": X.quantile(0.95).to_dict(),
             "min": X.min().to_dict(), "max": X.max().to_dict(), "q": {q: X.quantile(q).to_dict() for q in (0.3, 0.5, 0.9, 0.97)}}
    result = {"model": best, "best_name": best_name, "metrics": metrics, "features": feats, "importance": imp,
              "stats": stats, "target": target, "confusion": cm, "n_train": len(Xtr), "n_test": len(Xte),
              "positive_rate": float(y.mean()), "time_split": time_split}
    # Rare-event targets: scale level thresholds to the base rate (1.5x / 3x / 5x the event frequency)
    br = result["positive_rate"]
    result["thresholds"] = DEFAULT_TH if br >= 0.3 else tuple(round(min(br * m, 0.9), 2) for m in (1.5, 3, 5))
    if save:
        try:
            os.makedirs(MODEL_DIR, exist_ok=True)
            joblib.dump({k: result[k] for k in ("model", "features", "best_name")}, os.path.join(MODEL_DIR, "flood_model.pkl"))
        except Exception:
            pass
    return result


def predict_flood(res, values: dict):
    """values: {feature: number}. Returns probability, level."""
    row = pd.DataFrame([{f: values.get(f, res["stats"]["median"][f]) for f in res["features"]}])
    p = float(res["model"].predict_proba(row)[0, 1])
    return p, risk_level(p, res.get("thresholds", DEFAULT_TH))


def explain_flood(res, values: dict):
    """Occlusion-style local explanation: how much does probability change if a feature is set to its typical value?"""
    base_row = {f: values.get(f, res["stats"]["median"][f]) for f in res["features"]}
    p0 = float(res["model"].predict_proba(pd.DataFrame([base_row]))[0, 1])
    lg = lambda x: float(np.log(np.clip(x, 1e-6, 1 - 1e-6) / (1 - np.clip(x, 1e-6, 1 - 1e-6))))
    out = []
    for f in res["features"]:
        alt = dict(base_row)
        alt[f] = res["stats"]["median"][f]
        p1 = float(res["model"].predict_proba(pd.DataFrame([alt]))[0, 1])
        out.append((f, lg(p0) - lg(p1), base_row[f], res["stats"]["median"][f], p0 - p1))
    tot = sum(abs(t[1]) for t in out) or 1
    out.sort(key=lambda t: -abs(t[1]))
    rows = []
    for f, d, v, med, dp in out:
        share = abs(d) / tot
        impact = "Very High" if share > 0.4 else "High" if share > 0.2 else "Medium" if share > 0.08 else "Low"
        rows.append({"Feature": f, "Your value": round(v, 3), "Typical (median)": round(med, 3),
                     "Effect on risk": "increases" if d > 0.05 else "decreases" if d < -0.05 else "neutral",
                     "Change in probability (pts)": round(dp * 100, 1), "Impact": impact})
    return pd.DataFrame(rows)
