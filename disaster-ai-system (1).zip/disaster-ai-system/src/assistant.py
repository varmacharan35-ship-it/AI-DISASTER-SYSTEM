"""Disaster AI Assistant: offline rule-based knowledge base (DEMO/FALLBACK) + optional LLM if API key set."""
import os

SAFETY_NOTE = ("\n\n⚠️ *I am an informational assistant, not an emergency service. In a real emergency contact your "
               "local emergency services and follow official disaster-management instructions.*")

KB = [
    (["during earthquake", "earthquake", "shaking", "quake"],
     "**During an earthquake:**\n1. **DROP** to your hands and knees.\n2. **COVER** your head and neck under sturdy furniture.\n3. **HOLD ON** until shaking stops.\n4. Stay away from windows and falling objects; don't use elevators.\n5. Outdoors: move away from buildings, trees and power lines.\n6. Driving: stop safely and stay inside the vehicle."),
    (["after earthquake", "aftershock"],
     "**After an earthquake:** check yourself and others for injuries, expect aftershocks, avoid damaged buildings, check for gas/electrical hazards only if safe (leave if you smell gas), and follow official instructions."),
    (["water enters", "water in house", "water inside", "house flooded"],
     "**If water enters your house:** switch off electricity at the main only if you can do so without standing in water, move to an upper floor or higher ground, take documents/medicines/phone, don't touch electrical equipment, and call local emergency services if trapped."),
    (["electricity", "power off", "power cut", "blackout"],
     "**If electricity goes off during flooding:** do not touch wet switches or appliances, stay away from downed lines, use torches (not candles), keep phones/power banks charged, and never run a generator indoors."),
    (["evacuate", "evacuation", "leave home"],
     "**Should I evacuate?** Always follow official evacuation orders immediately. Leave early if water is rising quickly, your area is low-lying, or authorities advise it. Take your emergency kit, documents, medicines and use the routes authorities recommend."),
    (["kit", "emergency kit", "supplies", "go bag"],
     "**Emergency kit checklist:** drinking water (3 days), non-perishable food, first-aid kit, prescription medicines, torch + batteries, power bank, radio, copies of ID/documents in waterproof bag, whistle, blankets, cash, masks, baby/elderly/pet supplies."),
    (["children", "child", "elderly", "old people", "kids"],
     "**Protecting children & elderly:** keep them close and assign a helper, pack their medicines/diapers/special-diet items, keep them away from floodwater, practise drills calmly, and prioritise them in evacuation."),
    (["emergency number", "contact", "helpline", "call", "authority"],
     "**Who to contact:** your local emergency services, police, ambulance, fire & rescue, and the official disaster-management authority for your region. Numbers vary by location - check the Emergency Guide page and your government website."),
    (["flood", "during flood", "flooding"],
     "**During a flood:** move to higher ground when advised, never walk or drive through floodwater, stay away from electrical equipment and downed lines, follow evacuation orders, keep communication available."),
]
DEFAULT = ("I can help with earthquake and flood safety: what to do during/after, emergency kits, evacuation, water in the house, "
           "power cuts, children & elderly, and emergency contacts. Try asking one of those. For location-specific emergencies, "
           "follow your official local disaster-management alerts.")


def _get_key():
    k = os.environ.get("ANTHROPIC_API_KEY")
    if k:
        return k
    try:
        import streamlit as st
        return st.secrets.get("ANTHROPIC_API_KEY")
    except Exception:
        return None


def llm_available():
    if not _get_key():
        return False
    try:
        import anthropic  # noqa
        return True
    except Exception:
        return False


def answer(question, history=None, context=""):
    q = question.lower()
    if llm_available():
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=_get_key())
            system = ("You are 'Disaster AI Assistant' for earthquake and flood safety. Prioritise safety, be concise, use "
                      "numbered steps. You are NOT an emergency service and must not claim to predict earthquakes. For "
                      "location-specific emergencies tell users to follow official local authorities. " + context)
            msgs = [{"role": m["role"], "content": m["content"]} for m in (history or [])[-8:]] + [{"role": "user", "content": question}]
            r = client.messages.create(model="claude-sonnet-4-6", max_tokens=600, system=system, messages=msgs)
            return r.content[0].text + SAFETY_NOTE
        except Exception as e:
            fallback = f"*(LLM unavailable: {type(e).__name__}. Using offline knowledge base.)*\n\n"
    else:
        fallback = ""
    best, score = None, 0
    for keys, text in KB:
        s = sum(len(k) for k in keys if k in q)
        if s > score:
            best, score = text, s
    return fallback + (best or DEFAULT) + SAFETY_NOTE
