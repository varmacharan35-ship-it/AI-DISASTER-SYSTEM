"""Earthquake RISK INDICATOR from a historical catalogue (NOT a prediction of time/place/magnitude).
Heuristic score = f(local historical event density percentile, max historical magnitude nearby, shallow-depth share)."""
import numpy as np
import pandas as pd
from .preprocessing import detect_schema

DISCLAIMER = ("Earthquake risk estimates are probabilistic and cannot predict the exact time, "
              "location, or magnitude of future earthquakes.")


def haversine(lat1, lon1, lat2, lon2):
    R = 6371.0
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dphi, dl = p2 - p1, np.radians(lon2) - np.radians(lon1)
    a = np.sin(dphi / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(a))


class QuakeIndicator:
    def __init__(self, df, radius_km=300):
        s = detect_schema(df)
        if not {"magnitude", "lat", "lon"} <= set(s):
            raise ValueError("Catalogue needs magnitude, latitude and longitude columns.")
        d = pd.DataFrame({"mag": pd.to_numeric(df[s["magnitude"]], errors="coerce"),
                          "lat": pd.to_numeric(df[s["lat"]], errors="coerce"),
                          "lon": pd.to_numeric(df[s["lon"]], errors="coerce")})
        d["depth"] = pd.to_numeric(df[s["depth"]], errors="coerce") if "depth" in s else np.nan
        if "date" in s:
            d["date"] = pd.to_datetime(df[s["date"]], errors="coerce")
        self.df = d.dropna(subset=["mag", "lat", "lon"]).reset_index(drop=True)
        self.radius = radius_km
        samp = self.df.sample(min(len(self.df), 400), random_state=0)
        self.ref_counts = np.array([self._count(a, b) for a, b in zip(samp.lat, samp.lon)])

    def _count(self, lat, lon):
        return int((haversine(lat, lon, self.df.lat.values, self.df.lon.values) <= self.radius).sum())

    def assess(self, lat, lon):
        dist = haversine(lat, lon, self.df.lat.values, self.df.lon.values)
        near = self.df[dist <= self.radius]
        n = len(near)
        if n == 0:
            return {"score": 0.05, "level": "LOW", "n": 0, "max_mag": None, "mean_depth": None,
                    "nearest_km": float(dist.min()), "factors": ["No catalogued events within %d km" % self.radius]}
        pct = float((self.ref_counts <= n).mean())
        magscore = float(np.clip((near.mag.max() - 3.0) / 4.5, 0, 1))
        shallow = float((near.depth < 70).mean()) if near.depth.notna().any() else 0.5
        score = float(np.clip(0.5 * pct + 0.3 * magscore + 0.2 * shallow, 0.02, 0.95))
        level = "LOW" if score < 0.35 else "MODERATE" if score < 0.6 else "HIGH"
        factors = [f"{n} historical events within {self.radius} km (higher than {pct*100:.0f}% of catalogue locations)",
                   f"Largest historical magnitude nearby: M{near.mag.max():.1f}",
                   f"Share of shallow events (<70 km): {shallow*100:.0f}%",
                   f"Nearest catalogued event: {dist.min():.0f} km away"]
        return {"score": score, "level": level, "n": n, "max_mag": float(near.mag.max()),
                "mean_depth": float(near.depth.mean()) if near.depth.notna().any() else None,
                "nearest_km": float(dist.min()), "factors": factors}

    def hotspot(self):
        """Location of the densest historical cluster (used for demo scenario 3)."""
        samp = self.df.sample(min(len(self.df), 400), random_state=0).reset_index(drop=True)
        i = int(np.argmax(self.ref_counts))
        return float(samp.lat[i]), float(samp.lon[i])
