"""Combine flood probability and earthquake indicator into an alert level (in-app only)."""
ORDER = ["NORMAL", "WATCH", "WARNING", "EMERGENCY"]
STYLE = {
    "NORMAL": ("🟢", "#16a34a", "Conditions currently appear normal."),
    "WATCH": ("🟡", "#ca8a04", "Monitor weather and official alerts."),
    "WARNING": ("🟠", "#ea580c", "Prepare for possible hazardous conditions."),
    "EMERGENCY": ("🔴", "#dc2626", "High-risk conditions detected. Follow official emergency instructions."),
}
FLOOD_ACTIONS = {
    "NORMAL": ["Keep monitoring official weather updates.", "Review your family emergency plan."],
    "WATCH": ["Monitor weather forecasts and official alerts.", "Check your emergency kit and charge power banks.",
              "Know your nearest evacuation route."],
    "WARNING": ["Prepare to move valuables and documents to a higher place.", "Charge phones and keep emergency kit ready.",
                "Avoid low-lying areas and riverbanks.", "Follow local disaster-management updates."],
    "EMERGENCY": ["Move to higher ground if flooding is occurring or authorities advise evacuation.",
                  "Avoid walking or driving through floodwater.", "Keep emergency documents and medicines accessible.",
                  "Follow official government/local disaster-management instructions.", "Keep your phone charged."],
}
QUAKE_ACTIONS = ["Identify safe spots in each room (under sturdy furniture, away from windows).",
                 "Secure heavy furniture and keep an emergency kit ready.",
                 "Remember: DROP, COVER, HOLD ON during shaking.",
                 "Follow official seismology / disaster-management advisories."]


def flood_alert_level(p, th=(0.25, 0.5, 0.75)):
    return "NORMAL" if p < th[0] else "WATCH" if p < th[1] else "WARNING" if p < th[2] else "EMERGENCY"


def quake_alert_level(score):
    # An indicator can never justify EMERGENCY - capped at WARNING on purpose.
    return "NORMAL" if score < 0.35 else "WATCH" if score < 0.6 else "WARNING"


def overall_alert(flood_p, quake_score=None, th=(0.25, 0.5, 0.75)):
    f = flood_alert_level(flood_p, th) if flood_p is not None else "NORMAL"
    q = quake_alert_level(quake_score) if quake_score is not None else "NORMAL"
    lvl = max(f, q, key=ORDER.index)
    return {"level": lvl, "flood": f, "quake": q}


def banner_html(level, title, text=None):
    icon, color, default = STYLE[level]
    text = text or default
    return (f"<div style='background:{color}15;border-left:8px solid {color};padding:16px 20px;border-radius:10px;margin:8px 0'>"
            f"<div style='font-size:1.3rem;font-weight:800;color:{color}'>{icon} {title}</div>"
            f"<div style='color:#334155;margin-top:4px'>{text}</div></div>")
